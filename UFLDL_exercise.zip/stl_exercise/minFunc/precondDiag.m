function [y] = precondDiag(r,D)
y = D.*r;